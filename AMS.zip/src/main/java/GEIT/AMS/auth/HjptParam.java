package GEIT.AMS.auth;

public class HjptParam {

    public static String GHA_KEY = "GHA_KEY";

    public static String GHA_USERNAME = "GHA_USERNAME";

    public static String GHA_DPTCODE = "GHA_DPTCODE";
    
    public static String GHA_DPTNAME = "GHA_DPTNAME";
    
    public static String GHA_DPTCODEPARNT = "GHA_DPTCODEPARNT";
    
    public static String GHA_DPTLVLCODE = "GHA_DPTLVLCODE";
    
    public static String GHA_DPTLVLNAME = "GHA_DPTLVLNAME";
    
    public static String GHA_DPTPOSITCODE = "GHA_DPTPOSITCODE";
    
    public static String GHA_DPTPOSITNAME = "GHA_DPTPOSITNAME";

	public static String getGhaKey() {
		return GHA_KEY;
	}

	public static void setGhaKey(String ghaKey) {
		GHA_KEY = ghaKey;
	}

	public static String getGhaUsername() {
		return GHA_USERNAME;
	}

	public static void setGhaUsername(String ghaUsername) {
		GHA_USERNAME = ghaUsername;
	}

	public static String getGhaDptcode() {
		return GHA_DPTCODE;
	}

	public static void setGhaDptcode(String ghaDptcode) {
		GHA_DPTCODE = ghaDptcode;
	}

	public static String getGhaDptname() {
		return GHA_DPTNAME;
	}

	public static void setGhaDptname(String ghaDptname) {
		GHA_DPTNAME = ghaDptname;
	}

	public static String getGhaDptcodeparnt() {
		return GHA_DPTCODEPARNT;
	}

	public static void setGhaDptcodeparnt(String ghaDptcodeparnt) {
		GHA_DPTCODEPARNT = ghaDptcodeparnt;
	}

	public static String getGhaDptlvlcode() {
		return GHA_DPTLVLCODE;
	}

	public static void setGhaDptlvlcode(String ghaDptlvlcode) {
		GHA_DPTLVLCODE = ghaDptlvlcode;
	}

	public static String getGhaDptlvlname() {
		return GHA_DPTLVLNAME;
	}

	public static void setGhaDptlvlname(String ghaDptlvlname) {
		GHA_DPTLVLNAME = ghaDptlvlname;
	}

	public static String getGhaDptpositcode() {
		return GHA_DPTPOSITCODE;
	}

	public static void setGhaDptpositcode(String ghaDptpositcode) {
		GHA_DPTPOSITCODE = ghaDptpositcode;
	}

	public static String getGhaDptpositname() {
		return GHA_DPTPOSITNAME;
	}

	public static void setGhaDptpositname(String ghaDptpositname) {
		GHA_DPTPOSITNAME = ghaDptpositname;
	}
    
}
