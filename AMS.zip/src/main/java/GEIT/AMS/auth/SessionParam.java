package GEIT.AMS.auth;

public final class SessionParam{
	
	/**
	 * 행정포탈 세션정보
	 */
    public static final String ss_gha_key = "ss_gha_key";

    public static final String ss_gha_username = "ss_gha_username";

    public static final String ss_gha_dptcode = "ss_gha_dptcode";
    
    public static final String ss_gha_dptname = "ss_gha_dptname";
    
    public static final String ss_gha_dptcodeparnt = "ss_gha_dptcodeparnt";
    
    public static final String ss_gha_dptlvlcode = "ss_gha_dptlvlcode";
    
    public static final String ss_gha_dptlvlname = "ss_gha_dptlvlname";
    
    public static final String ss_gha_dptpositcode = "ss_gha_dptpositcode";
    
    public static final String ss_gha_dptpositname = "ss_gha_dptpositname";
	

	/**
	 * 시스템사용자 세션정보
	 */
    public static final String ss_id = "ss_id";

    public static final String ss_pwd = "ss_pwd";
    
    public static final String ss_userid = "ss_userid";

    public static final String ss_pmslvl = "ss_pmslvl";
    
    public static final String ss_msu_aprv_yn = "ss_msu_aprv_yn";
    
    public static final String ss_mti_dptno = "ss_dptno";
    
    public static final String ss_teamno = "ss_teamno";
    
    public static final String ss_auth_grp = "ss_auth_grp";
    
    public static final String ss_menu_pms = "ss_menu_pms";
    
    public static final String ss_is_vm = "ss_is_vm";
    
}
